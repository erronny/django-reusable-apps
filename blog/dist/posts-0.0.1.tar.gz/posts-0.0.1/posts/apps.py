from django.apps import AppConfig


class BloggerConfig(AppConfig):
    name = 'blogger'
